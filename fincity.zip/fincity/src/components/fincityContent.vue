<template>
  <div class="content">
    <div class="content-container">
      <img src="static/image (2).png" alt="">
      <h2>MAKE YOURSELF AT HOME IN 6 STEPS</h2>
      <div class="carousal">
        <Slick
          ref="Slick"
          :options="slickOptions"
          >
          <div class="outerc" v-for="(card, index) in carousalCards" :key="index">
                <div class="inner-circlec">
                    <h2>{{card.index}}</h2>
                </div>
                <div class="inner-circle2c">
                </div>
                <div class="headerc">
                    <h4>{{card.heading}}</h4>
                </div>
                <div class="card-contentc">
                  <p>{{card.content}}</p>
                </div>
            </div>
        </Slick>
        <!-- <VueSlickCarousel :="settings">
          <div class="outer" v-for="(card, index) in carousalCards" :key="index">
                <div class="inner-circle">
                    <h2>{{card.index}}</h2>
                </div>
                <div class="inner-circle2">
                </div>
                <div class="header">
                    <h4>{{card.heading}}</h4>
                </div>
                <div class="card-content">
                  <p>{{card.content}}</p>
                </div>
            </div>
        </VueSlickCarousel> -->
      </div>
      <div class = "card-container">
        <div class="outer" v-for="(card, index) in cards" :key="index">
                <div class="inner-circle">
                    <h2>{{card.index}}</h2>
                </div>
                <div class="inner-circle2">
                </div>
                <div class="header">
                    <h4>{{card.heading}}</h4>
                </div>
                <div class="card-content">
                  <p>{{card.content}}</p>
                </div>
            </div>
      </div>
    </div>
  </div>
</template>

<script>
 import Slick from 'vue-slick';
 import '../../node_modules/slick-carousel/slick/slick.css';
// import VueSlickCarousel from 'vue-slick-carousel'
//   // optional style for arrows & dots
//   import 'vue-slick-carousel/dist/vue-slick-carousel-theme.css'
export default {
 
  name: 'fincityContent',
  components:{
    // VueSlickCarousel,
    Slick,
  },
  data(){
    return{
      slickOptions:{
        dots: true,
        infinite: false,
        speed: 200,
        slidesToShow: 3,
        slidesToScroll: 3,
        autoplay: true,
        
        responsive: [
                    {
                      breakpoint: 1124,
                      settings: {
                        slidesToShow: 3,
                        slidesToScroll: 3,
                        infinite: true,
                        dots: false,
                        autoplay: true,
          
                      }
                    },
                    {
                      breakpoint: 1120,
                      settings: {
                        slidesToShow: 2,
                        slidesToScroll: 2,
                        infinite: true,
                        dots: false,
                        autoplay: true,
                      }
                    },
                    {
                      breakpoint: 840,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        infinite: true,
                        dots: false,
                        autoplay: true,
                      }
                    }
                    // You can unslick at a given breakpoint now by adding:
                    // settings: "unslick"
                    // instead of a settings object
                  ]
      },
      settings:{
        "dots": true,
        "focusOnSelect": true,
        "infinite": true,
        "speed": 500,
        "slidesToShow": 1,
        "slidesToScroll": 1,
        "touchThreshold": 5
      },
      cards : [{
            index: 'A',
            heading: 'Loan Offer',
            content: 'We are delighted to offer you a loan for the purchase of your dream home. You are now only two steps away: you will be required to e-sign the offer in acceptance, and will be provided with a provisional Sanction Letter.'
        },
        {
            index: 'B',
            heading: 'E-Sign',
            content: 'We are glad to know of your acceptance of our loan offer. Please e-sign the same, so that we can proceed with sharing a Provisional Sanction Letter'
        },
        {
            index: 'C',
            heading: 'Sanction Letter',
            content: 'Congratualtions! You are now offically one step away from realising what you dreamt!. Heres presenting a Provisonal Sanction Letter to be produced at the bank, and have them process your loan.'
        }
    ],
    carousalCards : [{
      index: 1,
      heading:'Sign Up & Check Credit Score',
      content:'Sign up to avail products from across diverse loans, properties,and being connected to over 50 lenders. In addition, check your Credit Score without impacting it, and get the best loan offer suited to your needs.'
    },
    {
      index:2,
      heading:'PAN Card Update',
      content:'Update your PAN Card with us so that we can perform a soft-check for your Credit Score. Upload a copy from your gallery anytime, anywhere.'
    },
    {
      index:3,
      heading:'Address Proof Update',
      content:'Update your address proof by uploading either your Driving License/Registered Rent Agreement/Utility Bill. You will, in no time, be made a loan offer to get closer to your dream home.'  
    },
    {
            index: 4,
            heading: 'Loan Offer',
            content: 'We are delighted to offer you a loan for the purchase of your dream home. You are now only two steps away: you will be required to e-sign the offer in acceptance, and will be provided with a provisional Sanction Letter.'
        },
        {
            index: 5,
            heading: 'E-Sign',
            content: 'We are glad to know of your acceptance of our loan offer. Please e-sign the same, so that we can proceed with sharing a Provisional Sanction Letter'
        },
        {
            index: 6,
            heading: 'Sanction Letter',
            content: 'Congratualtions! You are now offically one step away from realising what you dreamt!. Heres presenting a Provisonal Sanction Letter to be produced at the bank, and have them process your loan.'
        }]
    }
  },
  methods: {
        next() {
            this.$refs.slick.next();
        },
 
        prev() {
            this.$refs.slick.prev();
        },
 
        reInit() {
            // Helpful if you have to deal with v-for to update dynamic lists
            this.$nextTick(() => {
                this.$refs.slick.reSlick();
            });
        },
    },
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  h1{
    margin-top:0;
  }
  img {
    padding-top: 40px;
    padding-bottom: 20px;
  }
  .content{
    background-color: #00b8c4;
    padding-bottom: 20px;
  }
  .content-container{
    width: 80%;
    margin: 0px auto;
    text-align: center;
    color: white;
  }
  .carousal{
    /* display: flex; */
    /* padding: 20px 20px; */
    border: .5px solid white;
    border-radius: 1rem;
    margin: 20px 20px;
    flex-direction: row;
  }
  .card-container{
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    padding: 10px 10px;
    border: .5px solid white;
    border-radius: 1rem;
    flex-wrap: wrap;
    margin: 10px 10px;
    margin-bottom: 20px;
  }
  .outerc {
    height: 160px;
    width: 260px;
    background-color: white;
    border-radius: 24px;
     /* display: flex; */
    margin: 20px;
  }
  .inner-circlec {
    height: 50px;
    width: 50px;
    border-radius: 50px;
    position: absolute;
    background:#7bf6ff;
    border: 5px solid #00b8c4;
    margin-left: -15px;
    display: flex;
    text-align: center;
    justify-content: center;
    color: #00b8c4;
    margin-bottom: 0;
    z-index: 10;
  }
  .inner-circle2c{
    height: 60px;
    width: 60px;
    border-radius: 60px;
    position: absolute;
    background-color: white;
    z-index: 5;
    margin-left: -5px;
}
.headerc{
    width: 180px;
    height: 50px;
    position: relative;
    background-color: #00b8c4;
    z-index: 2;
    border-top-right-radius: 24px;
    margin: 5px;
    margin-left: 40px;
    display: flex;
    color: white;
}
.card-contentc{
    color: #00b8c4;
    padding-bottom: 5px;
    padding-left: 5px;
    padding-right: 5px;
}
.card-contentc > p{
  font-size: 12px;
}
  .outer{
    height: 160px;
    width: 260px;
    background-color: #7bf6ff;
    border-radius: 24px;
     /* display: flex; */
    margin: 20px;
}
.inner-circle{
    height: 50px;
    width: 50px;
    border-radius: 50px;
    position: absolute;
    background:white;
    border: 5px solid #00b8c4;
    margin-left: -15px;
    display: flex;
    text-align: center;
    justify-content: center;
    color: #00b8c4;
    margin-bottom: 0;
    z-index: 10;
}
h2{
    margin: 0;
    align-self: center;
}
.inner-circle2{
    height: 60px;
    width: 60px;
    border-radius: 60px;
    position: absolute;
    background-color: #7bf6ff;
    z-index: 5;
    margin-left: -5px;
}
.header{
    width: 180px;
    height: 50px;
    position: relative;
    background-color: #043f46ea;
    z-index: 2;
    border-top-right-radius: 24px;
    margin: 5px;
    margin-left: 40px;
    display: flex;
    color: white;
}
h4{
    margin: 0;
    margin-left: 18px;
    align-self: center;
}
.card-content{
  color: #444444;
  padding-bottom: 5px;
  padding-left: 5px;
  padding-right: 5px;
}
.card-content > p{
  font-size: 12px;
}
/* .slick-active{
  margin: 20px;
}  */
/* .slick-slide{
  width: 250px !important;
  margin: 20px 0 !important;
} */
</style>
