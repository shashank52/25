<template>
    <div class="footer">
        <div class="footer-container">
       <div class="heading">
                <img href="/" src="https://fincity-dev-public.s3.ap-south-1.amazonaws.com/website/com/images/fincity.png" style="max-width: 100px">
            </div>
            <div class="content">
                <div class="left">
                    <!-- <h2>fincity</h2> -->
                    <img src="../assets/fincity_location.png" alt="">
                </div>
                <div class="middle">
                    <div class="middle-left">
                        <table cellspacing="10">
                            <tr>
                                <th>Email-ID: </th>
                                <td>contact@fincity.com</td>
                            </tr>
                            <tr>
                                <th>Phone: </th>
                                <td>1234567890</td>
                            </tr>
                            <tr>
                                <th>Address: </th>
                                <td>33/1,3rd Floor, </td>
                            </tr>
                            <tr>
                                <th></th>
                                <td>Vittal Mallya Road,</td>
                            </tr>
                            <tr>
                                <th></th>
                                <td>(Near UB City),</td>
                            </tr>
                            <tr>
                                <th></th>
                                <td>Bangalore 560001</td>
                            </tr>
                        </table>
                    </div>
                    <div class="middle-middle">
                        <table cellspacing="10">
                            <tr>
                                <th>Company</th>
                            </tr>
                            <tr>
                                <td>About us</td>
                            </tr>
                            <tr>
                                <td>
                                    Terms of use
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    Privacy Policy
                                </td>
                            </tr>
                        </table>
                    </div>
                    <div class="middle-right">
                        <table cellspacing="10">
                            <tr>
                                <th>Products</th>
                            </tr>
                            <tr>
                                <td>Home Loan</td>
                            </tr>
                            <tr>
                                <td>Salaried</td>
                            </tr>
                            <tr>
                                <td>
                                    Self-Employed
                                </td>
                            </tr>
                            <tr>
                                <td>Pradhan Mantri Awas Yojana</td>
                            </tr>
                        </table>

                    </div>
                </div>
                <div class="right">
                    <div class="right-top">
                        <button>Carrer</button>
                        <button>Business Partner Registration</button>
                    </div>
                    <div class="right-bottom">
                        <img src="https://assets.transunion.com/resources/img/cibil-logo-lt.svg" alt="">
                        <img src="https://www.experian.in/wp-content/uploads/2017/08/experian.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>
<script>
export default {
    name: 'fincityFooter',
}
</script>

<style scoped>
.footer{
    background-color: white;
    width: 100%;
    margin-bottom: 20px;
}
.footer-container{
    display: flex;
    justify-content: space-around;
    width: 90%;
    margin: 0 auto;
    padding: 20px;
    flex-direction: column;
    flex-wrap: wrap;
}
.footer-container > .heading{
    color: #00b8c4;
    align-self: flex-start;
}
.footer-container > .content {
    display: flex;
    flex-direction: row;
    justify-content: space-around;
    flex-wrap: wrap;
}
.left{
    color: #00b8c4;
    align-self: flex-start;
}
.left > img{
    width: 200px;
    height: 250px;
    object-fit: cover;
}
.middle{
    display: flex;
    justify-content: space-around;
}
.middle-left{
    align-self: flex-start;
}
th{
    text-align: left;
}
tr{
    padding: 20px;
}
.middle-middle{
    align-self: flex-start;
}
button{
    padding: 0px;
    width: 150px;
    height: 50px;
    margin: 0 10px;
    background-color: #00b8c4;
    color: white;
    outline-color: #00b8c4;
    border-color: #00b8c4;
    border-radius: 5px;
    /* box-shadow: 0; */
}
button:hover{
    cursor: pointer;
    background-color: #043f46ea;
    outline-color: #043f46ea;
    border-color: #043f46ea;
}
.right{
    display: flex;
    justify-content: flex-start;
    flex-direction: column;
}
.right-top{
    display: flex;
    justify-content: flex-start;
}
.right-bottom{
    display: flex;
    justify-content: space-around;
    margin: 20px;
    
}
.right-bottom> img {
    max-width: 120px;
    max-height: 50px;
    align-self: flex-end;
}

@media (max-width: 1040px){
    .right{
        flex-direction: row;
        margin: 20px;
    }
    .right-bottom{
        justify-content: flex-end;
    }
}
@media (max-width: 700px){
    .right{
        flex-direction: column;
        margin: 20px;
    }
    .right-bottom{
        display: flex;
        justify-content: space-between;
        margin: 20px;
    }
    .footer-container > .heading{
        color: #00b8c4;
        align-self: center;
    }
    .left > img{
        width: 350px;
        height: 200px;
        object-fit: cover;
    }
    .middle{
        margin: 20px;
    }
    .left{
        margin: 20px;
    }

}
</style>