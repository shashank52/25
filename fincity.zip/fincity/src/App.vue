<template>
  <div id="app">
    <FincityContent></FincityContent>
    <FincityFooter></FincityFooter>
  </div>
</template>

<script>
import FincityContent from './components/fincityContent.vue'
import FincityFooter from './components/fincityFooter.vue'

export default {
  name: 'app',
  components: {
    FincityContent,
    FincityFooter,
  }
}
</script>

<style>
body{
  margin: 0;
  padding: 0;
  /* font-family: 'Andale Mono', monospace; */
}
#app{
  margin: 0;
  padding: 0;
}
.slick-slide{
  /* width: 250px !important; */
  margin: 30px;
  max-width: 260px;
}
.slick-slider{
  padding: 0 20px 0 20px;
}
.slick-dots{
position: absolute;
bottom: 20px;
display: flex;
justify-content: center;
width: calc(100% - 30px);
margin-top: 20px;
margin-bottom: 0px;
list-style: none;
text-align: center;

}
.slick-dots button {
  border-radius: 50%;
  width: 12px;
  height: 12px;
  outline: none;
  color: transparent;
  margin: 5px;
  background-color: #747474;
  border-color: #747474;
}
.slick-dots button:focus {
  width: 30px;
  height: 12px;
  border-radius: 20%;
}
/* .slick-active {
  width: 30px;
  height: 12px;
  border-radius: 20%;
} */
.carousal .slick-arrow{
    visibility: hidden;
}
</style>
